#!/usr/bin/env python3
"""
三省六部制 - 审计日志器
记录完整的任务流转历史，支持审计和复盘
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

class AuditLogger:
    """审计日志器"""
    
    def __init__(self, workspace_path: str):
        self.workspace = Path(workspace_path)
        self.log_dir = self.workspace / ".sansheng" / "audit"
        self.log_dir.mkdir(parents=True, exist_ok=True)
    
    def log_event(self, task_id: str, event_type: str, 
                  details: Dict, actor: str = "system"):
        """
        记录审计事件
        
        Args:
            task_id: 任务ID
            event_type: 事件类型 (create/update/transition/complete/cancel)
            details: 事件详情
            actor: 执行者 (system/user/department)
        """
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "task_id": task_id,
            "event_type": event_type,
            "actor": actor,
            "details": details
        }
        
        # 写入任务专属日志
        task_log_file = self.log_dir / f"{task_id}.log.jsonl"
        with open(task_log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
        
        # 同时写入全局日志
        global_log_file = self.log_dir / "global.log.jsonl"
        with open(global_log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
    
    def get_task_history(self, task_id: str) -> List[Dict]:
        """获取任务完整历史"""
        task_log_file = self.log_dir / f"{task_id}.log.jsonl"
        if not task_log_file.exists():
            return []
        
        history = []
        with open(task_log_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    history.append(json.loads(line))
        
        return history
    
    def get_recent_events(self, limit: int = 50) -> List[Dict]:
        """获取最近的事件"""
        global_log_file = self.log_dir / "global.log.jsonl"
        if not global_log_file.exists():
            return []
        
        events = []
        with open(global_log_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    events.append(json.loads(line))
        
        # 返回最近的N条
        return events[-limit:] if len(events) > limit else events
    
    def generate_report(self, task_id: str) -> Dict:
        """
        生成任务审计报告
        
        Returns:
            {
                "task_id": 任务ID,
                "duration": 总耗时,
                "phases": [各阶段耗时],
                "events": [关键事件],
                "statistics": 统计数据
            }
        """
        history = self.get_task_history(task_id)
        if not history:
            return {"error": "No history found"}
        
        # 计算总耗时
        start_time = datetime.fromisoformat(history[0]["timestamp"])
        end_time = datetime.fromisoformat(history[-1]["timestamp"])
        duration = (end_time - start_time).total_seconds()
        
        # 统计事件类型
        event_types = {}
        for event in history:
            et = event["event_type"]
            event_types[et] = event_types.get(et, 0) + 1
        
        # 提取关键事件
        key_events = [e for e in history if e["event_type"] in 
                     ["transition", "approval", "rejection", "completion"]]
        
        return {
            "task_id": task_id,
            "total_events": len(history),
            "duration_seconds": duration,
            "duration_formatted": self._format_duration(duration),
            "event_statistics": event_types,
            "key_events": key_events,
            "full_history": history
        }
    
    def generate_summary(self, days: int = 7) -> Dict:
        """
        生成周期汇总报告
        
        Args:
            days: 统计天数
        """
        cutoff = datetime.now().timestamp() - (days * 24 * 60 * 60)
        
        global_log_file = self.log_dir / "global.log.jsonl"
        if not global_log_file.exists():
            return {"error": "No log data"}
        
        tasks = set()
        events_by_type = {}
        events_by_actor = {}
        
        with open(global_log_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                event = json.loads(line)
                event_time = datetime.fromisoformat(event["timestamp"])
                
                if event_time.timestamp() < cutoff:
                    continue
                
                tasks.add(event["task_id"])
                
                et = event["event_type"]
                events_by_type[et] = events_by_type.get(et, 0) + 1
                
                actor = event["actor"]
                events_by_actor[actor] = events_by_actor.get(actor, 0) + 1
        
        return {
            "period_days": days,
            "total_tasks": len(tasks),
            "event_breakdown": events_by_type,
            "actor_breakdown": events_by_actor
        }
    
    def _format_duration(self, seconds: float) -> str:
        """格式化时长"""
        if seconds < 60:
            return f"{int(seconds)}秒"
        elif seconds < 3600:
            return f"{int(seconds/60)}分钟"
        else:
            hours = int(seconds / 3600)
            minutes = int((seconds % 3600) / 60)
            return f"{hours}小时{minutes}分钟"


def main():
    """CLI接口"""
    import argparse
    
    parser = argparse.ArgumentParser(description="三省六部审计日志器")
    parser.add_argument("--workspace", default=".", help="工作区路径")
    parser.add_argument("--action", required=True,
                       choices=["history", "report", "summary", "recent"],
                       help="操作类型")
    parser.add_argument("--task-id", help="任务ID")
    parser.add_argument("--days", type=int, default=7, help="统计天数")
    
    args = parser.parse_args()
    
    logger = AuditLogger(args.workspace)
    
    if args.action == "history":
        history = logger.get_task_history(args.task_id)
        print(json.dumps(history, ensure_ascii=False, indent=2))
    
    elif args.action == "report":
        report = logger.generate_report(args.task_id)
        print(json.dumps(report, ensure_ascii=False, indent=2))
    
    elif args.action == "summary":
        summary = logger.generate_summary(args.days)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    
    elif args.action == "recent":
        events = logger.get_recent_events()
        print(json.dumps(events, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
