#!/usr/bin/env python3
"""
三省六部制 - 状态管理器
维护任务流转状态，支持持久化和恢复
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from enum import Enum

class TaskStatus(Enum):
    """任务状态枚举"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"

class TaskPhase(Enum):
    """任务阶段枚举"""
    TAIZI = "太子分拣"
    ZHONGSHU = "中书省规划"
    MENXIA = "门下省审议"
    SHANGSHU = "尚书省调度"
    LIUBU = "六部执行"
    HUIZOU = "回奏汇报"

class StateManager:
    """任务状态管理器"""
    
    def __init__(self, workspace_path: str):
        self.workspace = Path(workspace_path)
        self.data_dir = self.workspace / ".sansheng" / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.current_task: Optional[Dict] = None
    
    def create_task(self, task_id: str, title: str, description: str, 
                    priority: str = "normal") -> Dict:
        """创建新任务"""
        task = {
            "id": task_id,
            "title": title,
            "description": description,
            "priority": priority,
            "status": TaskStatus.PENDING.value,
            "current_phase": TaskPhase.TAIZI.value,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "phases": {
                "taizi": {"status": TaskStatus.PENDING.value, "result": None},
                "zhongshu": {"status": TaskStatus.PENDING.value, "result": None, "plan": None},
                "menxia": {"status": TaskStatus.PENDING.value, "result": None, "approved": False},
                "shangshu": {"status": TaskStatus.PENDING.value, "result": None, "subtasks": []},
                "liubu": {"status": TaskStatus.PENDING.value, "departments": {}},
                "huizou": {"status": TaskStatus.PENDING.value, "result": None}
            },
            "audit_log": []
        }
        self._save_task(task)
        self.current_task = task
        return task
    
    def get_task(self, task_id: str) -> Optional[Dict]:
        """获取任务"""
        task_file = self.data_dir / f"{task_id}.json"
        if task_file.exists():
            with open(task_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    
    def update_phase(self, task_id: str, phase: str, 
                     status: TaskStatus, result: Any = None,
                     extra: Dict = None) -> Dict:
        """更新阶段状态"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        phase_key = phase.lower().replace("省", "").replace("部", "")
        if phase_key in task["phases"]:
            task["phases"][phase_key]["status"] = status.value
            if result is not None:
                task["phases"][phase_key]["result"] = result
            if extra:
                task["phases"][phase_key].update(extra)
        
        task["updated_at"] = datetime.now().isoformat()
        self._add_audit_log(task, f"Phase {phase} updated to {status.value}")
        self._save_task(task)
        return task
    
    def transition_to(self, task_id: str, phase: TaskPhase) -> Dict:
        """流转到下一阶段"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        task["current_phase"] = phase.value
        task["updated_at"] = datetime.now().isoformat()
        self._add_audit_log(task, f"Transitioned to {phase.value}")
        self._save_task(task)
        return task
    
    def add_subtask(self, task_id: str, department: str, 
                    subtask_id: str, description: str) -> Dict:
        """添加子任务"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        subtask = {
            "id": subtask_id,
            "department": department,
            "description": description,
            "status": TaskStatus.PENDING.value,
            "created_at": datetime.now().isoformat(),
            "completed_at": None,
            "result": None
        }
        
        task["phases"]["liubu"]["departments"][department] = subtask
        task["phases"]["shangshu"]["subtasks"].append(subtask_id)
        task["updated_at"] = datetime.now().isoformat()
        self._save_task(task)
        return task
    
    def update_subtask(self, task_id: str, department: str,
                       status: TaskStatus, result: Any = None) -> Dict:
        """更新子任务状态"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        if department in task["phases"]["liubu"]["departments"]:
            dept_task = task["phases"]["liubu"]["departments"][department]
            dept_task["status"] = status.value
            if result is not None:
                dept_task["result"] = result
            if status == TaskStatus.COMPLETED:
                dept_task["completed_at"] = datetime.now().isoformat()
        
        task["updated_at"] = datetime.now().isoformat()
        self._save_task(task)
        return task
    
    def get_all_tasks(self) -> List[Dict]:
        """获取所有任务"""
        tasks = []
        for task_file in self.data_dir.glob("*.json"):
            with open(task_file, 'r', encoding='utf-8') as f:
                tasks.append(json.load(f))
        return sorted(tasks, key=lambda x: x["created_at"], reverse=True)
    
    def get_active_tasks(self) -> List[Dict]:
        """获取进行中的任务"""
        all_tasks = self.get_all_tasks()
        return [t for t in all_tasks if t["status"] not in 
                [TaskStatus.COMPLETED.value, TaskStatus.CANCELLED.value]]
    
    def cancel_task(self, task_id: str, reason: str = "") -> Dict:
        """取消任务"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        task["status"] = TaskStatus.CANCELLED.value
        task["cancel_reason"] = reason
        task["updated_at"] = datetime.now().isoformat()
        self._add_audit_log(task, f"Task cancelled: {reason}")
        self._save_task(task)
        return task
    
    def complete_task(self, task_id: str, final_result: Any) -> Dict:
        """完成任务"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        task["status"] = TaskStatus.COMPLETED.value
        task["phases"]["huizou"]["result"] = final_result
        task["phases"]["huizou"]["status"] = TaskStatus.COMPLETED.value
        task["completed_at"] = datetime.now().isoformat()
        task["updated_at"] = datetime.now().isoformat()
        self._add_audit_log(task, "Task completed")
        self._save_task(task)
        return task
    
    def _save_task(self, task: Dict):
        """保存任务到文件"""
        task_file = self.data_dir / f"{task['id']}.json"
        with open(task_file, 'w', encoding='utf-8') as f:
            json.dump(task, f, ensure_ascii=False, indent=2)
    
    def _add_audit_log(self, task: Dict, message: str):
        """添加审计日志"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "message": message
        }
        task["audit_log"].append(log_entry)


def main():
    """CLI接口"""
    import argparse
    
    parser = argparse.ArgumentParser(description="三省六部状态管理器")
    parser.add_argument("--workspace", default=".", help="工作区路径")
    parser.add_argument("--action", required=True, 
                       choices=["create", "get", "update", "list", "active", "cancel", "complete"],
                       help="操作类型")
    parser.add_argument("--task-id", help="任务ID")
    parser.add_argument("--title", help="任务标题")
    parser.add_argument("--description", help="任务描述")
    parser.add_argument("--phase", help="阶段名称")
    parser.add_argument("--status", help="状态")
    parser.add_argument("--department", help="部门名称")
    
    args = parser.parse_args()
    
    manager = StateManager(args.workspace)
    
    if args.action == "create":
        import uuid
        task_id = args.task_id or f"task_{uuid.uuid4().hex[:8]}"
        task = manager.create_task(task_id, args.title or "Untitled", 
                                   args.description or "")
        print(json.dumps(task, ensure_ascii=False, indent=2))
    
    elif args.action == "get":
        task = manager.get_task(args.task_id)
        if task:
            print(json.dumps(task, ensure_ascii=False, indent=2))
        else:
            print(f"Task {args.task_id} not found")
    
    elif args.action == "list":
        tasks = manager.get_all_tasks()
        print(json.dumps(tasks, ensure_ascii=False, indent=2))
    
    elif args.action == "active":
        tasks = manager.get_active_tasks()
        print(json.dumps(tasks, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
