#!/usr/bin/env python3
"""
三省六部制 - 任务调度器
管理子Agent的创建、监控和结果收集
"""

import json
import time
import subprocess
from typing import Dict, List, Optional, Callable
from pathlib import Path

class TaskDispatcher:
    """任务调度器 - 尚书省的核心实现"""
    
    def __init__(self, workspace_path: str):
        self.workspace = Path(workspace_path)
        self.running_tasks: Dict[str, Dict] = {}
    
    def dispatch_subagent(self, task_id: str, department: str, 
                          description: str, prompt: str,
                          timeout: int = 600) -> Dict:
        """
        派发子任务给子Agent
        
        Args:
            task_id: 父任务ID
            department: 六部名称（吏/户/礼/兵/刑/工）
            description: 子任务描述
            prompt: 给子Agent的完整提示词
            timeout: 超时时间（秒）
        
        Returns:
            子任务信息字典
        """
        subtask_id = f"{task_id}_{department}_{int(time.time())}"
        
        # 构建子Agent提示词
        full_prompt = f"""【三省六部 - {department}部任务】

父任务ID: {task_id}
子任务ID: {subtask_id}
所属部门: {department}部

【任务描述】
{description}

【执行要求】
{prompt}

【输出格式】
请按以下格式返回结果：

## 执行摘要
简要说明完成的任务内容

## 详细输出
具体的输出内容（代码/文档/分析等）

## 状态报告
- 状态: [completed/failed]
- 耗时: 约X分钟
- 备注: 任何需要说明的事项

【注意事项】
1. 专注于{department}部的专业领域
2. 如遇到阻塞问题，明确说明
3. 输出应可直接用于后续阶段
"""
        
        subtask_info = {
            "id": subtask_id,
            "parent_id": task_id,
            "department": department,
            "description": description,
            "status": "dispatched",
            "created_at": time.time(),
            "timeout": timeout,
            "result": None
        }
        
        self.running_tasks[subtask_id] = subtask_info
        
        # 注意：实际的子Agent调用需要通过WorkBuddy的task工具
        # 这里返回任务信息供主Agent使用
        return subtask_info
    
    def dispatch_parallel(self, task_id: str, 
                          subtasks: List[Dict]) -> List[Dict]:
        """
        并行派发多个子任务
        
        Args:
            task_id: 父任务ID
            subtasks: 子任务列表，每项包含department, description, prompt
        
        Returns:
            子任务信息列表
        """
        dispatched = []
        for subtask in subtasks:
            info = self.dispatch_subagent(
                task_id=task_id,
                department=subtask["department"],
                description=subtask["description"],
                prompt=subtask["prompt"],
                timeout=subtask.get("timeout", 600)
            )
            dispatched.append(info)
        
        return dispatched
    
    def check_status(self, subtask_id: str) -> Optional[Dict]:
        """检查子任务状态"""
        return self.running_tasks.get(subtask_id)
    
    def collect_results(self, task_id: str) -> Dict:
        """
        收集所有子任务结果
        
        Returns:
            {
                "completed": [...],
                "failed": [...],
                "pending": [...],
                "results": {department: result}
            }
        """
        completed = []
        failed = []
        pending = []
        results = {}
        
        for subtask_id, info in self.running_tasks.items():
            if info["parent_id"] == task_id:
                dept = info["department"]
                if info["status"] == "completed":
                    completed.append(subtask_id)
                    results[dept] = info.get("result")
                elif info["status"] == "failed":
                    failed.append(subtask_id)
                else:
                    pending.append(subtask_id)
        
        return {
            "completed": completed,
            "failed": failed,
            "pending": pending,
            "results": results,
            "all_done": len(pending) == 0
        }
    
    def wait_for_completion(self, task_id: str, 
                           poll_interval: int = 5,
                           max_wait: int = 3600) -> Dict:
        """
        等待所有子任务完成
        
        Args:
            task_id: 父任务ID
            poll_interval: 轮询间隔（秒）
            max_wait: 最大等待时间（秒）
        
        Returns:
            收集结果
        """
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            status = self.collect_results(task_id)
            if status["all_done"]:
                return status
            time.sleep(poll_interval)
        
        # 超时返回当前状态
        return self.collect_results(task_id)
    
    def cancel_subtask(self, subtask_id: str) -> bool:
        """取消子任务"""
        if subtask_id in self.running_tasks:
            self.running_tasks[subtask_id]["status"] = "cancelled"
            return True
        return False
    
    def retry_subtask(self, subtask_id: str, 
                      new_prompt: Optional[str] = None) -> Optional[Dict]:
        """重试失败的子任务"""
        if subtask_id not in self.running_tasks:
            return None
        
        old_info = self.running_tasks[subtask_id]
        if old_info["status"] != "failed":
            return None
        
        # 创建新的子任务
        new_info = self.dispatch_subagent(
            task_id=old_info["parent_id"],
            department=old_info["department"],
            description=old_info["description"],
            prompt=new_prompt or f"重试任务：{old_info['description']}",
            timeout=old_info.get("timeout", 600)
        )
        
        return new_info


class DepartmentRouter:
    """六部路由器 - 根据任务内容分配部门"""
    
    DEPARTMENT_KEYWORDS = {
        "吏部": ["权限", "角色", "用户", "组织", "架构", "团队", "人员", "管理"],
        "户部": ["数据", "数据库", "存储", "报表", "统计", "分析", "财务", "SQL"],
        "礼部": ["文档", "文案", "内容", "撰写", "编写", "手册", "说明", "规范"],
        "兵部": ["代码", "开发", "实现", "架构", "设计", "算法", "API", "功能"],
        "刑部": ["审查", "测试", "安全", "检查", "审计", "验证", "评估", "质量"],
        "工部": ["部署", "配置", "环境", "运维", "CI/CD", "Docker", "服务器"]
    }
    
    @classmethod
    def route(cls, task_description: str) -> str:
        """
        根据任务描述路由到对应部门
        
        Returns:
            部门名称
        """
        task_lower = task_description.lower()
        scores = {}
        
        for dept, keywords in cls.DEPARTMENT_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in task_lower)
            scores[dept] = score
        
        # 返回得分最高的部门
        best_dept = max(scores, key=scores.get)
        
        # 如果所有得分都是0，默认分配给兵部
        if scores[best_dept] == 0:
            return "兵部"
        
        return best_dept
    
    @classmethod
    def analyze_complexity(cls, task_description: str) -> Dict:
        """
        分析任务复杂度
        
        Returns:
            {
                "level": "simple/medium/complex",
                "departments": [涉及的部门列表],
                "estimated_time": "预计耗时"
            }
        """
        task_lower = task_description.lower()
        
        # 统计涉及的部门
        involved = []
        for dept, keywords in cls.DEPARTMENT_KEYWORDS.items():
            if any(kw in task_lower for kw in keywords):
                involved.append(dept)
        
        # 判断复杂度
        if len(involved) <= 1 and len(task_description) < 100:
            level = "simple"
            estimated = "< 10分钟"
        elif len(involved) <= 3 and len(task_description) < 300:
            level = "medium"
            estimated = "10-30分钟"
        else:
            level = "complex"
            estimated = "> 30分钟"
        
        return {
            "level": level,
            "departments": involved if involved else ["兵部"],
            "estimated_time": estimated
        }


def main():
    """CLI接口"""
    import argparse
    
    parser = argparse.ArgumentParser(description="三省六部任务调度器")
    parser.add_argument("--workspace", default=".", help="工作区路径")
    parser.add_argument("--action", required=True,
                       choices=["route", "analyze", "dispatch"],
                       help="操作类型")
    parser.add_argument("--description", help="任务描述")
    parser.add_argument("--task-id", help="任务ID")
    parser.add_argument("--department", help="部门名称")
    
    args = parser.parse_args()
    
    if args.action == "route":
        dept = DepartmentRouter.route(args.description)
        print(json.dumps({"department": dept}, ensure_ascii=False))
    
    elif args.action == "analyze":
        result = DepartmentRouter.analyze_complexity(args.description)
        print(json.dumps(result, ensure_ascii=False))
    
    elif args.action == "dispatch":
        dispatcher = TaskDispatcher(args.workspace)
        info = dispatcher.dispatch_subagent(
            args.task_id, args.department, args.description, ""
        )
        print(json.dumps(info, ensure_ascii=False))


if __name__ == "__main__":
    main()
